name: Spec Validation

on:
  pull_request:
    branches: [main, develop]
  push:
    branches: [main]

jobs:
  validate-specs:
    name: Validate Specification Tree
    runs-on: ubuntu-latest
    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Set up Node.js
        uses: actions/setup-node@v4
        with:
          node-version: "22"

      - name: Install specgate
        run: npm install -g @rsaglobaltech/specgate@latest

      - name: Validate spec tree
        run: specgate validate .
